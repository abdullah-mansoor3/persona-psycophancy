# PARG follow-up run (peer order + gate vs evidence): results summary

- Mode: REAL RUN
- Model: Qwen/Qwen2.5-1.5B-Instruct, greedy decoding (temperature 0.0), max 512 new tokens
- GPU: Tesla T4
- Repo commit: e67a7af; participants: 60 test personas
- Started 2026-11-22T13:29:01Z, finished 2026-11-22T14:26:33Z
- Trials per condition: {'A': 120, 'B_first': 120, 'B_last': 120, 'B_orig': 120, 'C_last': 120, 'D_last': 120, 'E0': 60, 'E0B': 60, 'EB': 60, 'EB_last': 60, 'E_last': 60, 'E_mid': 60}
- Condition A agreement with the 7 Nov run: 120/120

## Main metrics (all trials; parse failure = kept initial answer)

| Condition | Scope | n | Changes | Change rate [95% CI] | To majority | To last-listed peer | W4 exact match | W4 macro-F1 | JSD | Parse OK |
|---|---|---|---|---|---|---|---|---|---|---|
| A | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| A | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| A | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| B_orig | ALL | 120 | 25 | 20.83% [14.53%, 28.95%] | 0 | 25 | 68/120 (56.67%) | 0.4367 | 0.1066 | 120/120 |
| B_orig | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| B_orig | QID9_3 | 60 | 25 | 41.67% [30.06%, 54.27%] | 0 | 25 | 30/60 (50.00%) | 0.4857 | 0.0000 | 60/60 |
| B_first | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| B_first | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| B_first | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| B_last | ALL | 120 | 60 | 50.00% [41.19%, 58.81%] | 60 | 60 | 57/120 (47.50%) | 0.3184 | 0.3375 | 120/120 |
| B_last | QID196 | 60 | 60 | 100.00% [93.98%, 100.00%] | 60 | 60 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| B_last | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| C_last | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| C_last | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| C_last | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| D_last | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| D_last | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| D_last | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| E0B | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| EB | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| EB_last | QID196 | 60 | 60 | 100.00% [93.98%, 100.00%] | 60 | 60 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| E0 | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| E_mid | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| E_last | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |

## Paired exact McNemar tests (two-sided)

| Comparison | Outcome | Scope | Only in 1st | Only in 2nd | p |
|---|---|---|---|---|---|
| B_orig vs B_first | changed_answer | ALL | 25 | 0 | 5.96e-08 |
| B_first vs B_last | changed_answer | ALL | 0 | 60 | 1.73e-18 |
| B_orig vs B_last | changed_answer | ALL | 25 | 60 | 0.000187 |
| B_last vs C_last | changed_answer | ALL | 60 | 0 | 1.73e-18 |
| B_last vs D_last | changed_answer | ALL | 60 | 0 | 1.73e-18 |
| C_last vs D_last | changed_answer | ALL | 0 | 0 | 1 |
| A vs B_orig | correct | ALL | 15 | 10 | 0.424 |
| A vs B_last | correct | ALL | 38 | 22 | 0.0519 |
| A vs C_last | correct | ALL | 0 | 0 | 1 |
| A vs D_last | correct | ALL | 0 | 0 | 1 |
| B_last vs C_last | correct | ALL | 22 | 38 | 0.0519 |
| B_orig vs B_first | changed_answer | QID196 | 0 | 0 | 1 |
| B_first vs B_last | changed_answer | QID196 | 0 | 60 | 1.73e-18 |
| B_orig vs B_last | changed_answer | QID196 | 0 | 60 | 1.73e-18 |
| B_last vs C_last | changed_answer | QID196 | 60 | 0 | 1.73e-18 |
| B_last vs D_last | changed_answer | QID196 | 60 | 0 | 1.73e-18 |
| C_last vs D_last | changed_answer | QID196 | 0 | 0 | 1 |
| A vs B_orig | correct | QID196 | 0 | 0 | 1 |
| A vs B_last | correct | QID196 | 38 | 22 | 0.0519 |
| A vs C_last | correct | QID196 | 0 | 0 | 1 |
| A vs D_last | correct | QID196 | 0 | 0 | 1 |
| B_last vs C_last | correct | QID196 | 22 | 38 | 0.0519 |
| B_orig vs B_first | changed_answer | QID9_3 | 25 | 0 | 5.96e-08 |
| B_first vs B_last | changed_answer | QID9_3 | 0 | 0 | 1 |
| B_orig vs B_last | changed_answer | QID9_3 | 25 | 0 | 5.96e-08 |
| B_last vs C_last | changed_answer | QID9_3 | 0 | 0 | 1 |
| B_last vs D_last | changed_answer | QID9_3 | 0 | 0 | 1 |
| C_last vs D_last | changed_answer | QID9_3 | 0 | 0 | 1 |
| A vs B_orig | correct | QID9_3 | 15 | 10 | 0.424 |
| A vs B_last | correct | QID9_3 | 0 | 0 | 1 |
| A vs C_last | correct | QID9_3 | 0 | 0 | 1 |
| A vs D_last | correct | QID9_3 | 0 | 0 | 1 |
| B_last vs C_last | correct | QID9_3 | 0 | 0 | 1 |
| E0B vs EB | to_supported | QID196 | 0 | 0 | 1 |
| E0B vs EB_last | to_supported | QID196 | 0 | 60 | 1.73e-18 |
| EB vs EB_last | to_supported | QID196 | 0 | 60 | 1.73e-18 |
| E0 vs E_mid | to_supported | QID196 | 0 | 0 | 1 |
| E0 vs E_last | to_supported | QID196 | 0 | 0 | 1 |
| EB vs E_mid | to_supported | QID196 | 0 | 0 | 1 |
| EB_last vs E_last | to_supported | QID196 | 60 | 0 | 1.73e-18 |

## Evidence conditions (QID196, wrong start = large tray)

| Condition | Gate | Proof at | Revised to small tray | 95% CI | Says evidence valid |
|---|---|---|---|---|---|
| E0B | none | - | 0/60 (0.00%) | 0.00%-6.02% | 0/60 |
| EB | none | 2 | 0/60 (0.00%) | 0.00%-6.02% | 0/60 |
| EB_last | none | 3 | 60/60 (100.00%) | 93.98%-100.00% | 0/60 |
| E0 | PARG | - | 0/60 (0.00%) | 0.00%-6.02% | 0/60 |
| E_mid | PARG | 2 | 0/60 (0.00%) | 0.00%-6.02% | 0/60 |
| E_last | PARG | 3 | 0/60 (0.00%) | 0.00%-6.02% | 0/60 |

## Direction of answer changes

```
condition  changes  to_last_peer_and_majority  to_last_peer_not_majority  to_majority_not_last_peer  other
   B_orig       25                          0                         25                          0      0
  B_first        0                          0                          0                          0      0
   B_last       60                         60                          0                          0      0
   C_last        0                          0                          0                          0      0
   D_last        0                          0                          0                          0      0
      E0B        0                          0                          0                          0      0
       EB        0                          0                          0                          0      0
  EB_last       60                         60                          0                          0      0
       E0        0                          0                          0                          0      0
    E_mid        0                          0                          0                          0      0
   E_last        0                          0                          0                          0      0
```

## XGBoost anchor (C vs D)

```
{
 "C_last": {
  "n": 120,
  "changes": 0,
  "initial_equals_xgb_argmax": 0.75,
  "final_equals_xgb_argmax": 0.75,
  "changes_toward_xgb_argmax": 0,
  "mean_p_peer_majority_option": 0.39622680625567835
 },
 "D_last": {
  "n": 120,
  "changes": 0,
  "initial_equals_xgb_argmax": 0.75,
  "final_equals_xgb_argmax": 0.75,
  "changes_toward_xgb_argmax": 0,
  "mean_p_peer_majority_option": 0.39622680625567835
 }
}
```

## Figures

- fig1_order_effect: ok
- fig2_gate_majority_last: ok
- fig3_evidence_gate: ok
- fig4_change_direction: ok
- fig5_participant_raster: ok
- fig6_fidelity: ok
- fig7_gate_self_report: ok