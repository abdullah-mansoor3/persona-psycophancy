# PARG re-run: results summary

- Mode: REAL RUN
- Model: Qwen/Qwen2.5-1.5B-Instruct, greedy decoding (temperature 0.0), max 512 new tokens
- GPU: Tesla T4
- Repo commit: e67a7af; participants: 60 test personas
- Started 2026-11-22T12:32:14Z, finished 2026-11-22T13:07:24Z
- Trials per condition: {'A': 120, 'B': 120, 'C': 120, 'D': 120, 'E': 60, 'E0': 60}
- Condition A agreement with the 7 Nov run: 120/120

## Main metrics (all trials; parse failure = kept initial answer)

| Condition | Scope | n | Changes | Change rate [95% CI] | Switched to majority | W4 exact match | W4 macro-F1 | JSD | Parse OK |
|---|---|---|---|---|---|---|---|---|---|
| A | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| A | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| A | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| B | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| B | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| B | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| C | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| C | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| C | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| D | ALL | 120 | 0 | 0.00% [0.00%, 3.10%] | 0 | 73/120 (60.83%) | 0.3781 | 0.2308 | 120/120 |
| D | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 38/60 (63.33%) | 0.3878 | 0.2133 | 60/60 |
| D | QID9_3 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 35/60 (58.33%) | 0.3684 | 0.2484 | 60/60 |
| E0 | ALL | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| E0 | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| E | ALL | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |
| E | QID196 | 60 | 0 | 0.00% [0.00%, 6.02%] | 0 | 22/60 (36.67%) | 0.2683 | 0.4267 | 60/60 |

## Paired exact McNemar tests (two-sided)

| Comparison | Outcome | Scope | Only in 1st | Only in 2nd | p |
|---|---|---|---|---|---|
| B vs C | changed_answer | ALL | 0 | 0 | 1 |
| B vs D | changed_answer | ALL | 0 | 0 | 1 |
| C vs D | changed_answer | ALL | 0 | 0 | 1 |
| A vs B | correct | ALL | 0 | 0 | 1 |
| A vs C | correct | ALL | 0 | 0 | 1 |
| A vs D | correct | ALL | 0 | 0 | 1 |
| B vs C | correct | ALL | 0 | 0 | 1 |
| B vs D | correct | ALL | 0 | 0 | 1 |
| B vs C | changed_answer | QID196 | 0 | 0 | 1 |
| B vs D | changed_answer | QID196 | 0 | 0 | 1 |
| C vs D | changed_answer | QID196 | 0 | 0 | 1 |
| A vs B | correct | QID196 | 0 | 0 | 1 |
| A vs C | correct | QID196 | 0 | 0 | 1 |
| A vs D | correct | QID196 | 0 | 0 | 1 |
| B vs C | correct | QID196 | 0 | 0 | 1 |
| B vs D | correct | QID196 | 0 | 0 | 1 |
| B vs C | changed_answer | QID9_3 | 0 | 0 | 1 |
| B vs D | changed_answer | QID9_3 | 0 | 0 | 1 |
| C vs D | changed_answer | QID9_3 | 0 | 0 | 1 |
| A vs B | correct | QID9_3 | 0 | 0 | 1 |
| A vs C | correct | QID9_3 | 0 | 0 | 1 |
| A vs D | correct | QID9_3 | 0 | 0 | 1 |
| B vs C | correct | QID9_3 | 0 | 0 | 1 |
| B vs D | correct | QID9_3 | 0 | 0 | 1 |
| E0 vs E | to_supported | QID196 | 0 | 0 | 1 |

## Evidence test (QID196, wrong start = large tray)

- E0: revised to small tray 0/60 (0.00%, 95% CI 0.00%-6.02%); flagged valid evidence 0/60
- E: revised to small tray 0/60 (0.00%, 95% CI 0.00%-6.02%); flagged valid evidence 0/60
- E0 vs E exact McNemar p = 1

## XGBoost anchor (C vs D)

```
{
 "C": {
  "n": 120,
  "changes": 0,
  "initial_equals_xgb_argmax": 0.75,
  "final_equals_xgb_argmax": 0.75,
  "changes_toward_xgb_argmax": 0,
  "mean_p_peer_majority_option": 0.39622680625567835
 },
 "D": {
  "n": 120,
  "changes": 0,
  "initial_equals_xgb_argmax": 0.75,
  "final_equals_xgb_argmax": 0.75,
  "changes_toward_xgb_argmax": 0,
  "mean_p_peer_majority_option": 0.39622680625567835
 }
}
```

## Figures

- fig1_peer_influence: ok
- fig2_answer_distribution: ok
- fig3_fidelity: ok
- fig4_evidence_test: ok
- fig5_gate_self_report: ok
- fig6_participant_raster: ok
- fig7_xgboost_anchor: ok