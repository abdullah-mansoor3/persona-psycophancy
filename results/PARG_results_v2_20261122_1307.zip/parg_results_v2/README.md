# PARG re-run (opposing peers, Condition D, wrong-start E)

Produced by `PARG_rerun_experiments.ipynb`. See `run_metadata.json` for the exact design, model, decoding settings and software versions, and `SUMMARY.md` for the headline numbers.

- `agent_outputs/agent_runs.csv|jsonl`: one row per trial (all conditions)
- `agent_outputs/prompts_and_raw_outputs.jsonl`: every prompt and the raw model output
- `agent_outputs/peer_groups_used.csv`: the exact peers shown to each persona
- `metrics/`: condition metrics (overall, per question, valid-only), paired tests, evidence test, gate self-report, XGBoost-anchor metrics
- `figures/`: PDF (for LaTeX) and 300-dpi PNG versions of every figure
